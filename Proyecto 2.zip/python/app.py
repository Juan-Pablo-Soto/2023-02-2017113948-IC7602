import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
import struct

import socket

from dns.message import from_wire

from flask import Flask, request, jsonify
import base64

cred = credentials.Certificate({
  "type": "service_account",
  "project_id": "redesp2-b32b5",
  "private_key_id": "b3aeaf029cec5af8dac519186cdf2dd1d275ae41",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQC68sq9aJbZMo0L\nTSb24gSdITKX9/LTRPpXwxRwMg3HGZNqU/z5hIcA+JufV7Zupqf8UZ8ZvPT3U+yS\nsOKvnSOTkLyS5iP8GPMRTSfSQYS8KXcUdEi8vRBLgqcp/zNYYmwcs22hScVmL8dI\nsyCBpKwj8zu4EU85BENE/sUpbkRRaJnPL9sEtrnrqDDwpYagXh//hNugUmbSszgK\njG5avimxZaDmwuBPFINxDWg+23SsG27SBbrH8z/eBP6xSmiPPSEUvMA0rwxfLR/M\n4/26+k7QvJpoNUImQEgc+7NU4iRUIEo6CX9e/x2Fvzz+advb0Kia2PgQJu0+wk5E\nzSRVIOtTAgMBAAECggEAD/i0J3BrCs1NzXxe6tKucDoo12DghvoqpRrOgTNViAAA\nXyIjx7Fx0zxqFzfoJxXn3h+fBxTknMi3umSQSU6UfoPsCGTPCDeddInx7/2W+HhW\naxHwMOe6H6le3LCn01I9SEpwAEqMKcnFLcnX6huGdV/PZ09bRFS/5oIZmAuKnKW8\nsplUhFqaR+Cp1ik7VAqMLsGgGW6b3zq71ShHWNB9sLxFJgNCXa2dRXjPOKquGC9x\nzcJzAzzw7dzlTE3D+bqecNc2fcPy0nJd6rMQJhAu9X+RIlqrlX9P529utcgRnNoN\n51/J7mnug6YKqxMn6j8YW+tanGt4YrOjU9N9Fi5QeQKBgQDfofSKYVmEJB0HlVWa\npRRwuXmp784M6yDWHKrLdjgNYX+ke3zlcOrQQJrLJyAJEqt/e+3GOrGWokr2SaBm\nDP+1lPQ98Jl2Wy/+iXpii61rNJTpCjs13N11JZ6SJ0ivnt51TgUybJUCrGROwijf\nh/JdyYTSnMcNCpQmzJiPqf8M7wKBgQDWAZx4S0BgO9F+6VKwQW6G11APB36ThbK0\nmbOGZ0BzxM//srgKR3ZsrmjMHoych053cVUkb/8JKwASgB9pi2coIQQ1Cq66tm9T\n92w4JOf6iA8Qs7cc97sBHJy5Du4GPwi8Tb1e/39SyWsaE+9HtJ3XdZOtHpnzw+KH\nJTpBGltP3QKBgGwQge/grPYa0WBZvF0XSnJSXkVNGT/K2zo77hiVju6AX8Lm3Wqu\nDvoFTge/Z06bE/5tr2+r6ycEU78Bwx2tSF/Bk+jee/nihKW2X0qBfpKgfRjDleso\nSGeUfzTXANvEpHEA+6frKnJ5RZt9XWzu76J8f8+abOGTbBX3pf0+Q35HAoGAdLP+\nOw92dMRKM3ZTtHCKMJhcPUXt/c7sLFahMws9d6R9dUhl2p0r9IqL9bw3G+khnjs8\nnhlBMCO172DVQH5X6+dNXwuLS6DPRy/nYRqnMtVdudL3aaGi5jFPOg/tN5TKU73l\nJlgYe/IBKQBz/Vt+tA+XT9IfTHKnJuHjSbtwzjUCgYB3+KAh3fXIE/d6rofPPPi+\nfhRZ5SLAKmtyh+RAghQTuo6vSr8EZL0/ag3JdaTvXhPSlxFmbHKd5zrTwjHcU78h\nDPPXTler9bFFowyd5CGgydDP3L4tPjMHZdbbquninlggjHu9ZpdN+96fgvbDjYEw\nkh7FOTb9lNWCX1PPzvlTOQ==\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-hwehk@redesp2-b32b5.iam.gserviceaccount.com",
  "client_id": "114346742001999268721",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-hwehk%40redesp2-b32b5.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
})
firebase_admin.initialize_app(cred, {'databaseURL':'https://redesp2-b32b5-default-rtdb.firebaseio.com/'})


def build_dns_query(hostname):
    # DNS header
    transaction_id = struct.pack('!H', 0x1234)
    flags = struct.pack('!H', 0x0100)  #Standard query
    questions = struct.pack('!H', 1)
    answer_rr = struct.pack('!H', 0)
    authority_rr = struct.pack('!H', 0)
    additional_rr = struct.pack('!H', 0)

    # DNS question
    qname = b''
    for part in hostname.split('.'):
        qname += struct.pack('!B', len(part))
        qname += part.encode('utf-8')
    qname += b'\x00'  #termina el string

    qtype = struct.pack('!H', 1)  # IPv4
    qclass = struct.pack('!H', 1)  # internet

    dns_query = transaction_id + flags + questions + answer_rr + authority_rr + additional_rr + qname + qtype + qclass
    return dns_query


def send_dns_query(query, dns_server, dns_port=53):
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.sendto(query, (dns_server, dns_port))
        response, _ = s.recvfrom(1024)
        #print(response)
    return response

def parse_dns_response(response_bytes):
    try:
        dns_response = from_wire(response_bytes)
        if(len(dns_response.answer) == 0):
            return 0
        first_answer = dns_response.answer[0]
        ip_address = str(first_answer[0])
     
        print(f"Transaction ID: {dns_response.id}")
        print(f"Response Code: {dns_response.rcode()}")
        for answer in dns_response.answer:
            print(f"Answer: {answer.name} - Type: {answer.rdtype} - TTL: {answer.ttl} - Data: {answer.items}")
        for authority in dns_response.authority:
            print(f"Authority: {authority.name} - Type: {authority.rdtype} - TTL: {authority.ttl} - Data: {authority.items}")
        for additional in dns_response.additional:
            print(f"Additional: {additional.name} - Type: {additional.rdtype} - TTL: {additional.ttl} - Data: {additional.items}")
            
        return ip_address
        
      
    except Exception as e:
        print(f"Error: {e}")
        return 0


def searchExternalDNS(hostname, dns_server = "8.8.8.8"):
    query = build_dns_query(hostname)
    response = send_dns_query(query, dns_server)
    return parse_dns_response(response)

def processHostFirebase(res):
    #test = json.loads(res)
    if(res["type"] == 'single'):
        return res["addresses"][1]
    if(res["type"] == 'multi'):
        #implementar round robin?
        return res["addresses"][1]
    if(res["type"] == 'weight'):
        #implementar weighted
        return res["addresses"][1]
    if(res["type"] == 'geo'):
        #implementar geo
        #searchIpToCountry()
        return res["addresses"][1]

def getHostFirebase(hostName, dns_server = "8.8.8.8"):
    print(hostName)
    ref = db.reference('hosts/')
    print(ref.get())
    items_ref = ref.order_by_child('hostname').equal_to(hostName).get()
    res = list(items_ref.items())
    if(len(res) == 0):
        print("no result in Firebase")
        external = searchExternalDNS(hostName, dns_server)
        if(not external):
            print("no result in external")
            return 0
        return external
        #aqui buscaria en el server externo
    else:
        ip = processHostFirebase(res[0][1])
        return ip

app = Flask(__name__)

@app.route('/api/dns_resolver', methods=['POST'])
def test():
    data = request.json['data']
    decoded_bytes = base64.b64decode(data)
    decoded_string = decoded_bytes.decode('utf-8')
    
    res = getHostFirebase(decoded_string)

    if(res == 0):
        res = "No existe el servidor"

    encoded_bytes = base64.b64encode(res.encode('utf-8'))

    encoded_string = encoded_bytes.decode('utf-8')
    return jsonify({'data' : encoded_string})


if __name__ == '__main__':
	app.run(debug=True, port=5000) 

