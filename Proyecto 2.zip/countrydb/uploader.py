
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
import csv

import ipaddress

cred = credentials.Certificate("C:\\Users\\juanp\\OneDrive\\Desktop\\temp\\ii23\\redews\\Proyecto 2\\python\\redesp2-b32b5-firebase-adminsdk-hwehk-b3aeaf029c.json")
firebase_admin.initialize_app(cred, {'databaseURL':'https://redesp2-b32b5-default-rtdb.firebaseio.com/'})

csv_file_path = 'C:\\Users\\juanp\\OneDrive\\Desktop\\temp\\ii23\\redews\\Proyecto 2\\countrydb\\dbip-country-lite-2023-11.csv'


def upload(a, b, c):
    ref = db.reference('/countries')
    ref.push({
        'country': c,
        'first':ip_to_decimal(a),
        'last':ip_to_decimal(b)
    })


def ip_to_decimal(ip_str):
    # Convert the IP address string to a decimal representation
    decimal_value = int(ipaddress.IPv4Address(ip_str))
    return decimal_value

ip_address_str = "192.168.1.1"
decimal_value = ip_to_decimal(ip_address_str)

if decimal_value is not None:
    print(f"The decimal value of {ip_address_str} is: {decimal_value}")

def cvsParser(path):
    with open(path, 'r', newline='') as csv_file:
        csv_reader = csv.reader(csv_file)
        for row in csv_reader:
            a = row[0]
            b = row[1]  
            c = row[2]
            upload(a, b, c)

cvsParser(csv_file_path)
print("done")