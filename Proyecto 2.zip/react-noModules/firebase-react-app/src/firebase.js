import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
    apiKey: "AIzaSyAlJP2ql_1rGMWZgkb6t4eusHz-T38-upI",

    authDomain: "redesp2-b32b5.firebaseapp.com",
  
    databaseURL: "https://redesp2-b32b5-default-rtdb.firebaseio.com",
  
    projectId: "redesp2-b32b5",
  
    storageBucket: "redesp2-b32b5.appspot.com",
  
    messagingSenderId: "232200316289",
  
    appId: "1:232200316289:web:57fca6a9d15f821cd4f480"
  
};
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

export default db;

