import React, { useState, useEffect } from "react";
import db from "./firebase";

import { ref, onValue, set, push, remove } from "firebase/database";


const Countries = () => {
    const [data, setData] = useState([]);
    const [newEntry, setNewEntry] = useState({ id: "", first: "", last: "", country: "" });

    const itemsPerPage = 40;
    
    const [currentPage, setCurrentPage] = useState(1);

    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;



    const [ipAddress, setIpAddress] = useState('');
    const [decimalVersion, setDecimalVersion] = useState(null);

    useEffect(() => {
        // Subscribe to changes in the "hosts" collection
        const hostsRef = ref(db, "countries");
        const unsubscribe = onValue(hostsRef, (snapshot) => {
          const hosts = snapshot.val();
          if (hosts) {
            setData(Object.entries(hosts).map(([id, host]) => ({ id, ...host })));
          } else {
            setData([]);
          }
        });
    
        // Unsubscribe when the component unmounts
        return () => unsubscribe();
      }, []);
    
    const handleAddEntry = async () => {
      // Manually set the ID if provided
      const entryId = newEntry.id || push(ref(db, "countries")).key;
  
      // Add new entry to the "hosts" collection
      await set(ref(db, `countries/${entryId}`), {
        first: newEntry.first,
        last: newEntry.last,
        country: newEntry.country,
      });
  
      setNewEntry({ id: "", first: "", last: "", country: [] });
    };
  
  
    const handleDeleteEntry = async (id) => {
      // Delete entry from the "hosts" collection
      const cRef = ref(db, `countries/${id}`);
      await remove(cRef);
    };

    const handleIncreasePage = () => {
        setCurrentPage((prevPage) => prevPage + 1);
    };

    const handleDecreasePage = () => {
        if (currentPage > 1) {
        setCurrentPage((prevPage) => prevPage - 1);
        }
    };

    const ipToDecimal = (ip) => {
        const octets = ip.split('.');
        return (
          (parseInt(octets[0], 10) << 24) +
          (parseInt(octets[1], 10) << 16) +
          (parseInt(octets[2], 10) << 8) +
          parseInt(octets[3], 10)
        );
    };



    const handleConvertClick = () => {
        setDecimalVersion(ipToDecimal(ipAddress));
    };

    

    return (
      <div>  
        <div> 
            <h3>Ip a decimal</h3>
            <input
              type="text"
              value={ipAddress}
              onChange={(e) => setIpAddress(e.target.value )}
            />
            <button onClick={handleConvertClick}>IP decimal</button>
            <h3>Ip {decimalVersion} </h3>
        </div>
        <h1> Nuevo rango </h1>
          <div>
            <label>ID (para modificar):</label>
            <input
              type="text"
              value={newEntry.id}
              onChange={(e) => setNewEntry({ ...newEntry, id: e.target.value })}
            />
          </div>
          <div>
            <label>First:</label>
            <input
              type="text"
              value={newEntry.first}
              onChange={(e) => setNewEntry({ ...newEntry, first: e.target.value })}
            />
          </div>
          <div>
            <label>Last:</label>
            <input
              type="text"
              value={newEntry.last}
              onChange={(e) => setNewEntry({ ...newEntry, last: e.target.value })}
            />
          </div>
          <div>
            <label>Country:</label>
            <input
              type="text"
              value={newEntry.country}
              onChange={(e) => setNewEntry({ ...newEntry, country: e.target.value })}
            />
          </div>
          <button onClick={handleAddEntry}>Nuevo rango</button>


        <div>
            <button onClick={handleDecreasePage}>Pagina anterior</button>
            <span> Pagina {currentPage} </span>
            <button onClick={handleIncreasePage}>Pagina siguiente</button>
        </div>
            <ul>
                {data.slice(startIndex, endIndex).map((entry) => (
                    <li key={entry.first}>
                        <span class="small">ID para modificar {entry.id}</span><br />
                        First IP {entry.first}<br />
                        Last IP {entry.last}<br />
                        Country {entry.country}
                        <button onClick={() => handleDeleteEntry(entry.id)}>Borrar rango IP</button>
                    </li>
                ))}
            </ul>

      </div>
      
    );
};

export default Countries;