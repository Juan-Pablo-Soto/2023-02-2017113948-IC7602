import React, { useState, useEffect } from "react";
import db from "./firebase";

import { ref, onValue, set, push, remove } from "firebase/database";


const Hosts = () => {
    const [data, setData] = useState([]);
    const [newEntry, setNewEntry] = useState({ id: "", hostname: "", type: "", addresses: [] });
  
    useEffect(() => {
      // Subscribe to changes in the "hosts" collection
      const hostsRef = ref(db, "hosts");
      const unsubscribe = onValue(hostsRef, (snapshot) => {
        const hosts = snapshot.val();
        if (hosts) {
          setData(Object.entries(hosts).map(([id, host]) => ({ id, ...host })));
        } else {
          setData([]);
        }
      });
  
      // Unsubscribe when the component unmounts
      return () => unsubscribe();
    }, []);
  
    const handleAddEntry = async () => {
      // Manually set the ID if provided
      const entryId = newEntry.id || push(ref(db, "hosts")).key;
  
      // Add new entry to the "hosts" collection
      await set(ref(db, `hosts/${entryId}`), {
        hostname: newEntry.hostname,
        type: newEntry.type,
        addresses: newEntry.addresses,
      });
  
      setNewEntry({ id: "", hostname: "", type: "", addresses: [] });
    };
  
  
    const handleDeleteEntry = async (id) => {
      // Delete entry from the "hosts" collection
      const hostRef = ref(db, `hosts/${id}`);
      await remove(hostRef);
    };
  
    return (
      <div>
        <h1> Nuevo server </h1>
          <div>
            <label>ID (para modificar):</label>
            <input
              type="text"
              value={newEntry.id}
              onChange={(e) => setNewEntry({ ...newEntry, id: e.target.value })}
            />
          </div>
          <div>
            <label>Hostname:</label>
            <input
              type="text"
              value={newEntry.hostname}
              onChange={(e) => setNewEntry({ ...newEntry, hostname: e.target.value })}
            />
          </div>
          <div>
            <label>Tipo:</label>
            <select
              value={newEntry.type}
              onChange={(e) => setNewEntry({ ...newEntry, type: e.target.value })}
            >
              <option value="weight">Weight</option>
              <option value="geo">Geo</option>
              <option value="multi">Multi</option>
              <option value="single">Single</option>
            </select>
          </div>
          <div>
            <label>Lista de direcciones IP:</label>
            <input
              type="text"
              value={newEntry.addresses.join(",")}
              onChange={(e) => setNewEntry({ ...newEntry, addresses: e.target.value.split(",") })}
            />
          </div>
          <button onClick={handleAddEntry}>Nuevo server</button>
       <br></br>

       <ul>
          {data.map((entry) => (
            <li key={entry.id}>
              <span class="small">ID: {entry.id}</span> 
              <br />
              <strong>Hostname:</strong> {entry.hostname}
              <br />
              <strong>Tipo:</strong>{`${entry.type}`}
              <br />
              <strong>Addresses:</strong> {JSON.stringify(entry.addresses)}
              <button onClick={() => handleDeleteEntry(entry.id)}>Borrar servidor</button>
            </li>
          ))}
        </ul>
      </div>
    );
};

export default Hosts;