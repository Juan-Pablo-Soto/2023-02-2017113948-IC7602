import logo from './logo.svg';
import './App.css';

import React, { useState, useEffect } from "react";
import db from "./firebase";
import { ref, onValue, set, push, remove } from "firebase/database";
import Hosts from "./hosts";
import Countries from './countries';

function App() {

  const [showHome, setShowHome] = useState(true);

  const toggleElement = () => {
    setShowHome(!showHome);
  };

  return (
    <div className="App">
      <button class="button" onClick={toggleElement}>Click para cambiar pagina</button>
      {showHome ? <Hosts /> : <Countries />}
    </div>
  );


}

export default App;
