#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include <curl/curl.h>

#define PORT 53

#define BUFFER_SIZE 1024


//Encoder
static const char base64_chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
char* base64_encode(const unsigned char *input, int length) {
    int output_length = 4 * ((length + 2) / 3); // len
    char *encoded_data = (char *)malloc(output_length + 1);
    if (encoded_data == NULL) {
        return encoded_data;
    }
    int i, j;
    for (i = 0, j = 0; i < length; i += 3, j += 4) {
        unsigned char octet_a = i < length ? input[i] : 0;
        unsigned char octet_b = i + 1 < length ? input[i + 1] : 0;
        unsigned char octet_c = i + 2 < length ? input[i + 2] : 0;
        encoded_data[j] = base64_chars[octet_a >> 2];
        encoded_data[j + 1] = base64_chars[((octet_a & 0x03) << 4) | (octet_b >> 4)];
        encoded_data[j + 2] = i + 1 < length ? base64_chars[((octet_b & 0x0F) << 2) | (octet_c >> 6)] : '=';
        encoded_data[j + 3] = i + 2 < length ? base64_chars[octet_c & 0x3F] : '=';
    }
    encoded_data[output_length] = '\0'; //Final de str
    return encoded_data;
}


//Decoder
int base64_decode_char(char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '+') return 62;
    if (c == '/') return 63;
    return -1; // Invalid character
}


unsigned char* base64_decode(const char *input, int *length) {
    int input_length = strlen(input);
    if (input_length % 4 != 0) {
        *length = 0;
        return NULL; // Invalid input length
    }

    *length = 3 * (input_length / 4);
    if (input[input_length - 1] == '=') (*length)--;
    if (input[input_length - 2] == '=') (*length)--;

    unsigned char *decoded_data = (unsigned char *)malloc(*length + 1);
    if (decoded_data == NULL) {
        *length = 0;
        return decoded_data;
    }

    int i, j;
    for (i = 0, j = 0; i < input_length; i += 4, j += 3) {
        int sextet_a = base64_decode_char(input[i]);
        int sextet_b = base64_decode_char(input[i + 1]);
        int sextet_c = base64_decode_char(input[i + 2]);
        int sextet_d = base64_decode_char(input[i + 3]);

        if (sextet_a == -1 || sextet_b == -1 || sextet_c == -1 || sextet_d == -1) {
            free(decoded_data);
            *length = 0;
            return NULL; // Invalid character in input
        }

        decoded_data[j] = (sextet_a << 2) | (sextet_b >> 4);
        if (input[i + 2] != '=') {
            decoded_data[j + 1] = ((sextet_b & 0x0F) << 4) | (sextet_c >> 2);
        }
        if (input[i + 3] != '=') {
            decoded_data[j + 2] = ((sextet_c & 0x03) << 6) | sextet_d;
        }
    }

    decoded_data[*length] = '\0'; // Null-terminate the string
    return decoded_data;
}







int main(int argc, char* argv[]){
    int server_socket, client_socket;
    struct sockaddr_in server_address, client_address;
    socklen_t client_address_length = sizeof(client_address);

    // Crear socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Error in socket creation");
        exit(1);
    }

        //socket Bind 
    server_address.sin_family = AF_INET;
    server_address.sin_port = htons(PORT);
    server_address.sin_addr.s_addr = INADDR_ANY;
    if (bind(server_socket, (struct sockaddr*)&server_address, sizeof(server_address)) < 0) {
        perror("Error in binding");
        exit(1);
    }

    // Listen for incoming connections
    if (listen(server_socket, 5) < 0) {
        perror("Error in listening");
        exit(1);
    }
    printf("Server listening on port %d...\n", PORT);

    int alive = 1;
    char *command, *codifiedCommand, *res, *decodifiedRes;
    while (alive) {
        // Accept a client connection
        client_socket = accept(server_socket, (struct sockaddr*)&client_address, &client_address_length);
        if (client_socket < 0) {
            perror("Error in accepting");
            continue;
        }
        

        char buffer[BUFFER_SIZE];
        char msgToClient[BUFFER_SIZE];

        ssize_t bytes_received;

        while ((bytes_received = recv(client_socket, buffer, sizeof(buffer), 0)) > 0) {
            buffer[bytes_received] = '\0'; 
            memset(msgToClient, 0, sizeof msgToClient);  
            command = strtok(buffer, " ");
            if (command == NULL) {
                continue;
            } 
            if (strcmp(command, "\n") == 0) {
                continue;
            }     
            if (strcmp(command, "exit") == 0) {
                printf("Exiting");
                alive = 0;
                break;
            }

            //se asume que command es un hostname a buscar
            codifiedCommand = base64_encode(command, strlen(command));
            //Se codifica

            //Se manda al API

            //Se recive respuesta

            //Se decodifica

            //Se devuelve al cliente
            
            strcpy(msgToClient, "Codificado: ");
            strcat(msgToClient, codifiedCommand);
            strcat(msgToClient, "\n");
            send(client_socket, msgToClient, strlen(msgToClient), 0);
        }

        close(client_socket);
    }

    close(server_socket);


    return 0;
}

